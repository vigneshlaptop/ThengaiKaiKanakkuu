# தேங்காய் காய் கணக்கு

Android app — பெயர் + காய் எண்ணிக்கை பதிவு செய்து மொத்தத்தை தானாகக் கூட்டும்.

## அம்சங்கள்
- தமிழ் UI
- பெயர் மற்றும் காய் எண்ணிக்கை சேர்க்கலாம்
- மொத்த காய் எண்ணிக்கை தானாக கணக்கிடப்படும்
- Edit / Delete
- Internet தேவையில்லை
- தரவு phone-ல் SharedPreferences மூலம் சேமிக்கப்படும்

## APK உருவாக்குவது
Android Studio-ல் இந்த project-ஐ திறந்து:
Build → Build App Bundle(s) / APK(s) → Build APK(s)

Debug APK பொதுவாக:
app/build/outputs/apk/debug/app-debug.apk
