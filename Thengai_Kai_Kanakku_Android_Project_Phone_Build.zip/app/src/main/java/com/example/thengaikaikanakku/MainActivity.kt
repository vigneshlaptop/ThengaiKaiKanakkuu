package com.example.thengaikaikanakku

import android.app.AlertDialog
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONArray
import org.json.JSONObject

data class Entry(var name: String, var count: Int)

class MainActivity : AppCompatActivity() {
    private val entries = mutableListOf<Entry>()
    private lateinit var list: LinearLayout
    private lateinit var totalText: TextView
    private val prefs by lazy { getSharedPreferences("data", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        load()
        buildUi()
        refresh()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 20)
        }

        val title = TextView(this).apply {
            text = "🥥 தேங்காய் காய் கணக்கு"
            textSize = 25f
            setTextColor(0xFF2E7D32.toInt())
            setPadding(0, 0, 0, 18)
        }
        root.addView(title)

        val name = EditText(this).apply {
            hint = "பெயர்"
            textSize = 18f
            singleLine = true
        }
        root.addView(name)

        val count = EditText(this).apply {
            hint = "காய் எண்ணிக்கை"
            textSize = 18f
            inputType = InputType.TYPE_CLASS_NUMBER
            singleLine = true
        }
        root.addView(count)

        val add = Button(this).apply {
            text = "➕ கணக்கில் சேர்"
            textSize = 17f
            setOnClickListener {
                val n = name.text.toString().trim()
                val c = count.text.toString().toIntOrNull()
                if (n.isEmpty() || c == null || c < 0) {
                    Toast.makeText(this@MainActivity, "பெயர் மற்றும் சரியான காய் எண்ணிக்கை உள்ளிடுங்கள்", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                entries.add(Entry(n, c))
                name.text.clear()
                count.text.clear()
                save()
                refresh()
            }
        }
        root.addView(add)

        totalText = TextView(this).apply {
            textSize = 22f
            gravity = Gravity.CENTER
            setPadding(8, 18, 8, 18)
        }
        root.addView(totalText)

        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        setContentView(root)
    }

    private fun refresh() {
        list.removeAllViews()
        entries.forEachIndexed { index, e ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(10, 8, 4, 8)
            }
            val text = TextView(this).apply {
                text = "${e.name}  —  ${e.count} காய்கள்"
                textSize = 19f
            }
            row.addView(text, LinearLayout.LayoutParams(0, -2, 1f))

            val edit = Button(this).apply {
                text = "✏️"
                setOnClickListener { editEntry(index) }
            }
            row.addView(edit)

            val del = Button(this).apply {
                text = "🗑️"
                setOnClickListener {
                    entries.removeAt(index)
                    save()
                    refresh()
                }
            }
            row.addView(del)
            list.addView(row)
        }
        val total = entries.sumOf { it.count }
        totalText.text = "மொத்தம்: $total காய்கள்"
    }

    private fun editEntry(index: Int) {
        val e = entries[index]
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 10, 40, 0)
        }
        val name = EditText(this).apply { setText(e.name); hint = "பெயர்" }
        val count = EditText(this).apply {
            setText(e.count.toString())
            hint = "காய் எண்ணிக்கை"
            inputType = InputType.TYPE_CLASS_NUMBER
        }
        box.addView(name)
        box.addView(count)

        AlertDialog.Builder(this)
            .setTitle("கணக்கை மாற்று")
            .setView(box)
            .setNegativeButton("ரத்து", null)
            .setPositiveButton("சேமி") { _, _ ->
                val c = count.text.toString().toIntOrNull()
                val n = name.text.toString().trim()
                if (!n.isNullOrEmpty() && c != null && c >= 0) {
                    entries[index] = Entry(n, c)
                    save()
                    refresh()
                }
            }.show()
    }

    private fun save() {
        val arr = JSONArray()
        entries.forEach {
            arr.put(JSONObject().apply {
                put("name", it.name)
                put("count", it.count)
            })
        }
        prefs.edit().putString("entries", arr.toString()).apply()
    }

    private fun load() {
        val raw = prefs.getString("entries", "[]") ?: "[]"
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                entries.add(Entry(o.getString("name"), o.getInt("count")))
            }
        } catch (_: Exception) { }
    }
}
