# Phone-only APK build

The easiest phone-only method is GitHub Actions.

1. Create/sign in to a GitHub account in Chrome.
2. Create a new repository, e.g. `ThengaiKaiKanakku`.
3. Upload ALL files from this project ZIP, keeping folders intact.
4. Open the repository → **Actions**.
5. Open **Build Android APK**.
6. Tap **Run workflow** (or push to `main`, which starts it automatically).
7. Wait for the workflow to finish.
8. Open the completed workflow run.
9. Under **Artifacts**, download `Thengai-Kai-Kanakku-debug-apk`.
10. Extract the downloaded artifact ZIP. Inside it is `app-debug.apk`.
11. Tap the APK and install it. Android may ask you to allow installation from that source.

No computer is required for this method.
